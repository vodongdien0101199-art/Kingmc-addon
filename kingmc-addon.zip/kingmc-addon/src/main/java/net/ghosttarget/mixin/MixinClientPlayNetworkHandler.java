package net.ghosttarget.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.ghosttarget.modules.GhostTargetModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class MixinClientPlayNetworkHandler {
    private long lastBypass = 0;

    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        GhostTargetModule module = Modules.get().get(GhostTargetModule.class);
        if (module == null || !module.isActive()) return;

        if (System.currentTimeMillis() - lastBypass < 10) return;

        // Chặn các packet quan trọng để thêm delay ngẫu nhiên
        if (packet instanceof PlayerInteractEntityC2SPacket ||
            packet instanceof PlayerActionC2SPacket ||
            packet instanceof PlayerMoveC2SPacket) {

            // Delay ngẫu nhiên 5-25ms để giống người thật
            try {
                Thread.sleep(5 + (int)(Math.random() * 20));
            } catch (InterruptedException ignored) {}

            lastBypass = System.currentTimeMillis();
        }
    }
}