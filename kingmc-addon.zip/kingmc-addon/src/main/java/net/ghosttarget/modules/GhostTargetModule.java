package net.ghosttarget.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import net.ghosttarget.GhostTargetAddon;

public class GhostTargetModule extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    // ===== SETTINGS =====
    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("Max distance to find target")
        .defaultValue(10.0)
        .min(1.0)
        .max(30.0)
        .sliderMax(20.0)
        .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Delay between ghost packets (ms)")
        .defaultValue(50)
        .min(10)
        .max(200)
        .sliderMax(150)
        .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
        .name("rotate")
        .description("Rotate player to target")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> fakePlayer = sgGeneral.add(new BoolSetting.Builder()
        .name("fake-player")
        .description("Make server see a fake player at target position")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> debug = sgGeneral.add(new BoolSetting.Builder()
        .name("debug")
        .description("Print debug info")
        .defaultValue(false)
        .build()
    );

    // ===== STATE =====
    private PlayerEntity target = null;
    private Vec3d ghostPos = null;
    private long lastUpdate = 0;

    public GhostTargetModule() {
        super(GhostTargetAddon.MOD_ID, "ghost-target", "Ghost your position to target. Server sees a fake player at target position.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;
        if (System.currentTimeMillis() - lastUpdate < delay.get()) return;

        // 1. Find nearest target
        target = mc.world.getPlayers().stream()
            .filter(e -> e != mc.player)
            .filter(e -> !e.isRemoved() && e.isAlive())
            .filter(e -> e.distanceTo(mc.player) <= range.get())
            .min((a, b) -> Double.compare(a.distanceTo(mc.player), b.distanceTo(mc.player)))
            .orElse(null);

        if (target == null) {
            if (debug.get()) System.out.println("[GhostTarget] No target found.");
            return;
        }

        // 2. Ghost position = target position
        ghostPos = target.getPos();

        // 3. Send fake packets to server
        // Server sẽ thấy player đang đứng tại vị trí của target
        sendGhostPackets();

        if (debug.get()) {
            System.out.println("[GhostTarget] Target: " + target.getName().getString() +
                " | Ghost at: " + ghostPos);
        }

        lastUpdate = System.currentTimeMillis();
    }

    private void sendGhostPackets() {
        if (mc.player.networkHandler == null) return;

        // ---- Packet 1: Fake position - server thấy player đang ở target ----
        mc.player.networkHandler.sendPacket(
            new PlayerMoveC2SPacket.PositionAndOnGround(
                ghostPos.x,
                ghostPos.y,
                ghostPos.z,
                true
            )
        );

        // ---- Packet 2: Fake rotation - nhìn về phía target ----
        if (rotate.get()) {
            float yaw = (float) Math.toDegrees(Math.atan2(
                target.getZ() - mc.player.getZ(),
                target.getX() - mc.player.getX()
            )) - 90;

            mc.player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, -90, true)
            );
        }

        // ---- Packet 3: Fake Player - gửi thêm packet để server tin chắc ----
        if (fakePlayer.get()) {
            // Gửi 2 packet liên tiếp để server xác nhận vị trí ảo
            mc.player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.PositionAndOnGround(
                    ghostPos.x,
                    ghostPos.y + 0.1,
                    ghostPos.z,
                    true
                )
            );

            // Gửi packet on-ground để hoàn thiện
            mc.player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.OnGroundOnly(true)
            );
        }
    }

    // ===== GETTERS =====
    public PlayerEntity getTarget() { return target; }
    public Vec3d getGhostPos() { return ghostPos; }
}