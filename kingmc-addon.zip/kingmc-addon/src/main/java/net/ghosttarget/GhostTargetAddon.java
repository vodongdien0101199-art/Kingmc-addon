package net.ghosttarget;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.ghosttarget.modules.GhostTargetModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GhostTargetAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("ghosttarget");
    public static final String MOD_ID = "ghosttarget";

    @Override
    public void onInitialize() {
        LOG.info("[GhostTarget] Loading Meteor Addon...");
        Modules.get().add(new GhostTargetModule());
        LOG.info("[GhostTarget] Loaded successfully.");
    }

    @Override
    public String getPackage() {
        return "net.ghosttarget";
    }
}