Termux build wrapper

Run:
  chmod +x gradlew
  ./gradlew build

This project uses a self-bootstrapping Gradle launcher because the original ZIP did not contain gradle/wrapper/gradle-wrapper.jar. It downloads Gradle 8.10.2 on first run.
